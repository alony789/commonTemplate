/**
 * api模块接口列表
 */
import apiFunction from "gw-base-api-plus/apiFunction";
import template from "./api/template";

const api = Object.assign({}, apiFunction, template);

export default api;
